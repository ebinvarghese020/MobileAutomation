package base;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


public class Reuseable {
		private static WebDriver driver;		
		
		/**
	     * Constructor for Reuseable class.
	     * @param driver The WebDriver object.
	     */
		public Reuseable(WebDriver driver) {
			this.driver = driver;
		}
		
		/**
		 * Method to take a screenshot.
		 * @param filepath The file path where the screenshot will be saved.
		 */
		public static void takeScreenShot(String filepath) {
			TakesScreenshot takeScreenShot = (TakesScreenshot)driver;
			File srcFile = takeScreenShot.getScreenshotAs(OutputType.FILE);
			File destFile = new File(filepath);
			try {
				FileUtils.copyFile(srcFile, destFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
}
