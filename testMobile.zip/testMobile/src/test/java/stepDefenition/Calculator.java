package stepDefenition;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeClass;

import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.CalculatorPom;

public class Calculator {
	AndroidDriver driver;
	public CalculatorPom calculator;
	
	public Calculator() {
		driver = Hooks.driver;
		calculator = new CalculatorPom(driver);
	}
	
	@Given("User Already on the calculator application")
	public void user_already_on_the_calculator_application() {
	    System.out.println("User on calculator");
	}

	@When("User performs multiplication, clicks {string} {string} {string}")
	public void user_performs_multiplication_clicks(String string, String string2, String string3) {
	    calculator.multiplyCucumber();
	}

	@Then("I validate the outcomes, as {string}.")
	public void i_validate_the_outcomes_as(String string) {
	    assertEquals(calculator.validateResult(), "2");
	}
}
