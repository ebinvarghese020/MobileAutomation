package ust.testMobile;

import static org.testng.Assert.assertEquals;

import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.Reuseable;
import base.Setup;
import pom.CalculatorPom;
import utils.DataProviders;

@Listeners(utils.ExtentReportsListener.class)
public class CalculatorTest extends Setup{
	public CalculatorPom calculator;
	public Reuseable reuse;
	
	@BeforeClass
	public void setUp() {
		calculator = new CalculatorPom(driver);
		reuse = new Reuseable(driver);
	}
	
	@Test
	public void testAdd() {
		calculator.add();
		assertEquals(calculator.validateResult(), "3");		
	}
	
	@Test
	public void testMultiplication() {
		calculator.multiply();
		assertEquals(calculator.validateResult(), "2");
	}
	
	@Test(dataProvider = "Jsondata", dataProviderClass = DataProviders.class)
	public void testaddJson(HashMap<String,String> map) {
		calculator.addJson(map.get("val1"), map.get("val2"));
		assertEquals(calculator.validateResult(), map.get("result"));
	}
}
